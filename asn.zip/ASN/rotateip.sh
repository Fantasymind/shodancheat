#!/bin/bash

while true; do
    nordvpn connect
    sleep 80
done

